Author:  Zachary Qin

Version: 1.0

Date: June 17, 2022

Instructions:
    To install, uninstall, and run the program follow the instructions in the INSTALL file

# EDIT
General Instructions:
	2048 presents with with a 4×4 grid. 
	When you start the game, there will be two “tiles” on the grid, each displaying the number 2 or 4. 
	You hit the arrow keys (or wasd) on your keyboard to move the tiles around and also to generate new tiles, which will also be valued at 2 or 4. 
	When two equal tiles collide, they combine to give you one greater tile that displays their sum. 
	The more you do this, the higher the tiles get and the more crowded the board becomes. 
	Your objective is to reach 2048 before the board fills up.

